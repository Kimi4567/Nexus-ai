import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary">
      {/* Navigation */}
      <nav className="border-b border-dark-tertiary bg-dark/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-accent">NEXUS</div>
          <div className="flex gap-6 items-center">
            <Link href="/auth/login" className="text-sm hover:text-accent transition">
              Login
            </Link>
            <Link
              href="/auth/register"
              className="text-sm px-4 py-2 bg-accent text-dark rounded-lg hover:bg-accent-light transition"
            >
              Sign Up
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 animate-fade-in">
        <div className="max-w-3xl">
          <h1 className="text-6xl font-bold mb-6 leading-tight">
            AI Marketing <br />
            <span className="text-accent">Operating System</span>
          </h1>
          <p className="text-xl text-gray-400 mb-8">
            Generate complete marketing campaigns in minutes. Strategies, ad scripts, videos, and social content—powered by AI.
          </p>

          <div className="flex gap-4 mb-16">
            <Link
              href="/auth/register"
              className="px-8 py-3 bg-accent text-dark font-semibold rounded-lg hover:bg-accent-light transition"
            >
              Start Free
            </Link>
            <button className="px-8 py-3 border border-accent text-accent rounded-lg hover:bg-accent/10 transition">
              Watch Demo
            </button>
          </div>

          <div className="grid grid-cols-3 gap-8 text-sm">
            <div>
              <div className="text-2xl font-bold text-accent mb-2">5x</div>
              <div className="text-gray-400">Faster campaigns</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-accent mb-2">$0</div>
              <div className="text-gray-400">Setup cost</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-accent mb-2">1000s</div>
              <div className="text-gray-400">Assets generated</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-4xl font-bold mb-16 text-center">Everything You Need</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Feature 1 */}
          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8 hover:border-accent/50 transition">
            <div className="w-12 h-12 bg-accent/20 rounded-lg mb-4 flex items-center justify-center">
              <span className="text-accent text-xl">📊</span>
            </div>
            <h3 className="text-xl font-semibold mb-3">Strategy First</h3>
            <p className="text-gray-400">
              AI analyzes your business and generates data-driven marketing strategies optimized for your industry.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8 hover:border-accent/50 transition">
            <div className="w-12 h-12 bg-accent/20 rounded-lg mb-4 flex items-center justify-center">
              <span className="text-accent text-xl">🎬</span>
            </div>
            <h3 className="text-xl font-semibold mb-3">Video Generation</h3>
            <p className="text-gray-400">
              Create professional ad videos, shorts, and thumbnails optimized for TikTok, Instagram, and YouTube.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8 hover:border-accent/50 transition">
            <div className="w-12 h-12 bg-accent/20 rounded-lg mb-4 flex items-center justify-center">
              <span className="text-accent text-xl">✍️</span>
            </div>
            <h3 className="text-xl font-semibold mb-3">Content Library</h3>
            <p className="text-gray-400">
              Get scripts, captions, headlines, and CTAs tailored to each platform and audience segment.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8 hover:border-accent/50 transition">
            <div className="w-12 h-12 bg-accent/20 rounded-lg mb-4 flex items-center justify-center">
              <span className="text-accent text-xl">🎯</span>
            </div>
            <h3 className="text-xl font-semibold mb-3">AI Agent Mode</h3>
            <p className="text-gray-400">
              Let our AI analyze your content and automatically suggest improvements and variations.
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h2 className="text-4xl font-bold mb-6">Ready to Transform Your Marketing?</h2>
        <p className="text-xl text-gray-400 mb-8">
          Join hundreds of businesses generating campaigns in minutes, not weeks.
        </p>
        <Link
          href="/auth/register"
          className="inline-block px-8 py-4 bg-accent text-dark font-semibold rounded-lg hover:bg-accent-light transition"
        >
          Start Free Trial (No Credit Card)
        </Link>
      </section>
    </div>
  )
}
