'use client'

import { useAuth } from '@/lib/auth-context'
import Link from 'next/link'
import { useEffect, useState } from 'react'

export default function BillingPage() {
  const { isAuthenticated, loading, user } = useAuth()
  const [mode, setMode] = useState('mock')

  useEffect(() => {
    if (process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) setMode('live')
  }, [])

  if (loading) return <div className="min-h-screen bg-dark flex items-center justify-center">Loading...</div>
  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary">
      <nav className="border-b border-dark-tertiary bg-dark/50 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/dashboard">
            <h1 className="text-2xl font-bold text-accent">NEXUS</h1>
          </Link>
          <div className="text-sm text-gray-400">Billing</div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8">
          <h1 className="text-3xl font-bold mb-2">Billing & Subscription</h1>
          <p className="text-gray-400 mb-6">Manage your subscription, view usage, and upgrade to unlock more AI credits.</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-dark rounded-lg p-6 border border-dark-tertiary">
              <div className="text-sm text-gray-400">Current Plan</div>
              <div className="font-semibold mt-2">{user?.subscriptionStatus || 'FREE'}</div>
            </div>
            <div className="bg-dark rounded-lg p-6 border border-dark-tertiary">
              <div className="text-sm text-gray-400">AI Credits</div>
              <div className="font-semibold mt-2">{user?.aiCredits ?? 0}</div>
            </div>
            <div className="bg-dark rounded-lg p-6 border border-dark-tertiary">
              <div className="text-sm text-gray-400">Usage This Month</div>
              <div className="font-semibold mt-2">Generations: 12 • Exports: 3</div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-2">Plans</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border border-dark-tertiary rounded-lg bg-dark">
                <div className="font-bold">Starter</div>
                <div className="text-sm text-gray-400">$19 / month • 100 AI credits</div>
                <button className="mt-4 px-4 py-2 bg-accent text-dark rounded-md">Choose Starter</button>
              </div>
              <div className="p-4 border border-dark-tertiary rounded-lg bg-dark">
                <div className="font-bold">Pro</div>
                <div className="text-sm text-gray-400">$49 / month • 500 AI credits</div>
                <button className="mt-4 px-4 py-2 bg-accent text-dark rounded-md">Choose Pro</button>
              </div>
              <div className="p-4 border border-dark-tertiary rounded-lg bg-dark">
                <div className="font-bold">Agency</div>
                <div className="text-sm text-gray-400">Custom pricing • Team features</div>
                <button className="mt-4 px-4 py-2 bg-accent text-dark rounded-md">Contact Sales</button>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <p className="text-sm text-gray-400">Mode: {mode === 'live' ? 'Live Stripe' : 'Mock (no keys)'} — switch to live by adding Stripe keys.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
