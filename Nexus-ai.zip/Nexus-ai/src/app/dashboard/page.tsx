'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { useAuth } from '@/lib/auth-context'

export default function Dashboard() {
  const router = useRouter()
  const { user, logout, isAuthenticated, loading } = useAuth()

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      router.push('/auth/login')
    }
  }, [isAuthenticated, loading, router])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary flex items-center justify-center">
        <div className="text-xl text-gray-400">Loading...</div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  const stats = [
    { label: 'Total Campaigns', value: '—', icon: '📊' },
    { label: 'AI Credits', value: String(user?.aiCredits || 0), icon: '⚡' },
    { label: 'Generations', value: '—', icon: '🎬' },
    { label: 'Active Workspaces', value: '—', icon: '🏢' },
  ]

  const [overview, setOverview] = useState<any>(null)
  const [activity, setActivity] = useState<any[]>([])

  useEffect(() => {
    ;(async () => {
      try {
        const res = await fetch('/api/analytics/overview')
        const data = await res.json()
        if (!data.error) setOverview(data)
      } catch (err) {}
    })()

    ;(async () => {
      try {
        const res = await fetch('/api/analytics/activity')
        const data = await res.json()
        if (!data.error) setActivity(data.uploads || [])
      } catch (err) {
        console.error('Failed to load activity', err)
      }
    })()
  }, [])

  const recentCampaigns = [
    {
      id: '1',
      name: 'Summer Sale Campaign',
      goal: 'Sales',
      platforms: ['TikTok', 'Instagram'],
      status: 'Active',
      date: 'Today',
    },
    {
      id: '2',
      name: 'Product Launch',
      goal: 'Awareness',
      platforms: ['YouTube', 'Facebook'],
      status: 'Draft',
      date: 'Yesterday',
    },
    {
      id: '3',
      name: 'Brand Storytelling',
      goal: 'Engagement',
      platforms: ['TikTok'],
      status: 'Published',
      date: '2 days ago',
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary">
      {/* Navigation */}
      <nav className="border-b border-dark-tertiary bg-dark/50 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-8">
            <Link href="/dashboard">
              <h1 className="text-2xl font-bold text-accent cursor-pointer hover:text-accent-light transition">
                NEXUS
              </h1>
            </Link>
            <div className="flex gap-6 text-sm">
              <Link href="/dashboard" className="text-accent hover:text-accent-light transition font-semibold">
                Dashboard
              </Link>
              <a href="#campaigns" className="text-gray-400 hover:text-white transition">
                Campaigns
              </a>
              <a href="#analytics" className="text-gray-400 hover:text-white transition">
                Analytics
              </a>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-400">{user?.email}</span>
            <button
              onClick={logout}
              className="px-4 py-2 text-sm bg-dark-tertiary hover:bg-dark-tertiary/80 rounded-lg transition"
            >
              Sign Out
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <h2 className="text-4xl font-bold mb-2">Welcome back, {user?.name}! 👋</h2>
          <p className="text-gray-400">Here's your marketing performance overview</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-dark-secondary border border-dark-tertiary rounded-lg p-6 hover:border-accent/50 transition">
              <div className="text-3xl mb-2">{stat.icon}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
              <div className="text-2xl font-bold mt-2">{overview ? (stat.label === 'Total Campaigns' ? overview.campaignsCount : stat.label === 'Generations' ? overview.generationsCount : stat.label === 'AI Credits' ? String(user?.aiCredits || 0) : overview.exportsCount) : stat.value}</div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Link
            href="/campaign/new"
            className="bg-accent text-dark rounded-lg p-8 hover:bg-accent-light transition font-semibold text-lg text-center"
          >
            ➕ Create New Campaign
          </Link>
          <Link
            href="/imports"
            className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8 hover:border-accent/50 transition font-semibold text-center"
          >
            📤 Import Assets
          </Link>
          <Link
            href="/templates"
            className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8 hover:border-accent/50 transition font-semibold text-center"
          >
            📋 Use Templates
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
          <div className="lg:col-span-2 bg-dark-secondary border border-dark-tertiary rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold">Recent Upload Activity</h3>
                <p className="text-sm text-gray-400">Track upload events and audit entries across your workspace.</p>
              </div>
            </div>
            <div className="space-y-3">
              {activity.length > 0 ? (
                activity.map((event) => (
                  <div key={event.id} className="rounded-3xl border border-dark-tertiary bg-dark p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <div className="font-semibold text-white">{event.eventType.replace(/_/g, ' ')}</div>
                        <div className="text-sm text-gray-400">{event.metadata?.fileName || event.metadata?.mediaId || 'Upload event'}</div>
                      </div>
                      <div className="text-xs text-gray-500">{new Date(event.createdAt).toLocaleString()}</div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-sm text-gray-400">No recent upload activity yet.</div>
              )}
            </div>
          </div>

          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-3">Media usage</h3>
            <p className="text-sm text-gray-400">Uploaded assets are attached to campaigns and are prepared for future AI analysis pipelines.</p>
            <div className="mt-4 grid gap-2">
              <div className="rounded-2xl bg-dark p-3 text-sm text-gray-300">Campaign media attaches directly to draft and published campaigns.</div>
              <div className="rounded-2xl bg-dark p-3 text-sm text-gray-300">Upload sessions include workspace/project/campaign context and expire safely.</div>
            </div>
          </div>
        </div>

        {/* Recent Campaigns */}
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg overflow-hidden" id="campaigns">
          <div className="p-6 border-b border-dark-tertiary">
            <h3 className="text-xl font-bold">Recent Campaigns</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-dark-tertiary text-sm text-gray-400 bg-dark-tertiary/50">
                  <th className="text-left p-4 font-semibold">Campaign</th>
                  <th className="text-left p-4 font-semibold">Goal</th>
                  <th className="text-left p-4 font-semibold">Platforms</th>
                  <th className="text-left p-4 font-semibold">Status</th>
                  <th className="text-left p-4 font-semibold">Date</th>
                  <th className="text-left p-4 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {recentCampaigns.map((campaign) => (
                  <tr key={campaign.id} className="border-b border-dark-tertiary hover:bg-dark/50 transition">
                    <td className="p-4">
                      <div className="font-semibold">{campaign.name}</div>
                    </td>
                    <td className="p-4 text-sm text-gray-300">{campaign.goal}</td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        {campaign.platforms.map((p) => (
                          <span key={p} className="text-xs bg-dark-tertiary px-2 py-1 rounded">
                            {p}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="p-4">
                      <span
                        className={`text-xs px-2 py-1 rounded ${
                          campaign.status === 'Active'
                            ? 'bg-green-500/20 text-green-200'
                            : campaign.status === 'Draft'
                            ? 'bg-yellow-500/20 text-yellow-200'
                            : 'bg-blue-500/20 text-blue-200'
                        }`}
                      >
                        {campaign.status}
                      </span>
                    </td>
                    <td className="p-4 text-sm text-gray-400">{campaign.date}</td>
                    <td className="p-4">
                      <Link
                        href={`/campaign/${campaign.id}`}
                        className="text-accent hover:text-accent-light transition text-sm font-semibold"
                      >
                        View →
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
