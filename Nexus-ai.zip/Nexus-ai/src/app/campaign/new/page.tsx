'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'
import { useAuth } from '@/lib/auth-context'

export default function CreateCampaignPage() {
  const router = useRouter()
  const { isAuthenticated, loading } = useAuth()
  const [step, setStep] = useState(1)
  const [campaignData, setCampaignData] = useState({
    name: '',
    goal: 'sales',
    industry: 'ecommerce',
    platforms: [] as string[],
    budget: '1000',
    description: '',
  })
  const [draftId, setDraftId] = useState<string | null>(null)

  if (loading) return <div className="min-h-screen bg-dark flex items-center justify-center">Loading...</div>
  if (!isAuthenticated) return null

  const platforms = ['TikTok', 'Instagram', 'YouTube', 'Facebook', 'LinkedIn']
  const goals = ['Sales', 'Awareness', 'Engagement', 'Leads', 'Traffic']
  const industries = ['E-commerce', 'SaaS', 'Finance', 'Healthcare', 'Education']

  const togglePlatform = (platform: string) => {
    setCampaignData(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platform)
        ? prev.platforms.filter(p => p !== platform)
        : [...prev.platforms, platform]
    }))
  }

  const handleNext = () => {
    if (step < 3) setStep(step + 1)
  }

  const handleSubmit = () => {
    // Finalize: save campaign to backend if draft exists
    ;(async () => {
      try {
        if (draftId) {
          // Update would be implemented later; for now redirect
          router.push(`/campaign/${draftId}`)
          return
        }
        const res = await fetch('/api/campaigns', { method: 'POST', body: JSON.stringify(campaignData), headers: { 'Content-Type': 'application/json' } })
        const data = await res.json()
        if (data.campaign) router.push(`/campaign/${data.campaign.id}`)
        else router.push('/dashboard')
      } catch (err) {
        console.error(err)
        router.push('/dashboard')
      }
    })()
  }

  // Autosave draft to backend and localStorage
  useEffect(() => {
    const key = 'nexus_campaign_draft'
    const stored = localStorage.getItem(key)
    if (stored) {
      try {
        const parsed = JSON.parse(stored)
        setCampaignData(parsed.data)
        setDraftId(parsed.id || null)
      } catch {}
    }

    const timer = setInterval(async () => {
      try {
        // save to localStorage
        localStorage.setItem(key, JSON.stringify({ id: draftId, data: campaignData }))
        // save to backend: create or patch
        if (!draftId) {
          const res = await fetch('/api/campaigns', { method: 'POST', body: JSON.stringify(campaignData), headers: { 'Content-Type': 'application/json' } })
          const data = await res.json()
          if (data.campaign && data.campaign.id) setDraftId(data.campaign.id)
        } else {
          await fetch(`/api/campaigns/${draftId}`, { method: 'PATCH', body: JSON.stringify(campaignData), headers: { 'Content-Type': 'application/json' } })
        }
      } catch (err) {
        // ignore autosave errors
      }
    }, 6_000)

    return () => clearInterval(timer)
  }, [campaignData, draftId])

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary">
      {/* Header */}
      <nav className="border-b border-dark-tertiary bg-dark/50 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/dashboard">
            <h1 className="text-2xl font-bold text-accent cursor-pointer hover:text-accent-light transition">
              NEXUS
            </h1>
          </Link>
          <div className="text-sm text-gray-400">Step {step} of 3</div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-6 py-12">
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8">
          <h1 className="text-3xl font-bold mb-8">Create New Campaign</h1>

          {/* Step 1: Basic Info */}
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-3">Campaign Name</label>
                <input
                  type="text"
                  value={campaignData.name}
                  onChange={(e) => setCampaignData({ ...campaignData, name: e.target.value })}
                  placeholder="e.g., Summer Sale Campaign"
                  className="w-full px-4 py-3 bg-dark border border-dark-tertiary rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-accent transition"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-3">Campaign Goal</label>
                  <select
                    value={campaignData.goal}
                    onChange={(e) => setCampaignData({ ...campaignData, goal: e.target.value })}
                    className="w-full px-4 py-3 bg-dark border border-dark-tertiary rounded-lg text-white focus:outline-none focus:border-accent transition"
                  >
                    {goals.map((goal) => (
                      <option key={goal} value={goal.toLowerCase()}>
                        {goal}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-3">Industry</label>
                  <select
                    value={campaignData.industry}
                    onChange={(e) => setCampaignData({ ...campaignData, industry: e.target.value })}
                    className="w-full px-4 py-3 bg-dark border border-dark-tertiary rounded-lg text-white focus:outline-none focus:border-accent transition"
                  >
                    {industries.map((ind) => (
                      <option key={ind} value={ind.toLowerCase()}>
                        {ind}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-3">Description</label>
                <textarea
                  value={campaignData.description}
                  onChange={(e) => setCampaignData({ ...campaignData, description: e.target.value })}
                  placeholder="Describe your campaign objectives..."
                  rows={4}
                  className="w-full px-4 py-3 bg-dark border border-dark-tertiary rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-accent transition"
                />
              </div>
            </div>
          )}

          {/* Step 2: Platforms & Budget */}
          {step === 2 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-4">Select Platforms</label>
                <div className="grid grid-cols-2 gap-3">
                  {platforms.map((platform) => (
                    <button
                      key={platform}
                      onClick={() => togglePlatform(platform)}
                      className={`p-4 rounded-lg border-2 transition ${
                        campaignData.platforms.includes(platform)
                          ? 'border-accent bg-accent/10'
                          : 'border-dark-tertiary bg-dark hover:border-accent/50'
                      }`}
                    >
                      <div className="font-semibold">{platform}</div>
                      {campaignData.platforms.includes(platform) && (
                        <div className="text-accent text-xs mt-1">✓ Selected</div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-3">Monthly Budget</label>
                <div className="flex items-center gap-2">
                  <span className="text-xl">$</span>
                  <input
                    type="number"
                    value={campaignData.budget}
                    onChange={(e) => setCampaignData({ ...campaignData, budget: e.target.value })}
                    className="flex-1 px-4 py-3 bg-dark border border-dark-tertiary rounded-lg text-white focus:outline-none focus:border-accent transition"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Review */}
          {step === 3 && (
            <div className="space-y-6">
              <div className="bg-dark rounded-lg p-6 space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Campaign Name:</span>
                  <span className="font-semibold">{campaignData.name || 'N/A'}</span>
                </div>
                <div className="flex justify-between border-t border-dark-tertiary pt-4">
                  <span className="text-gray-400">Goal:</span>
                  <span className="font-semibold capitalize">{campaignData.goal}</span>
                </div>
                <div className="flex justify-between border-t border-dark-tertiary pt-4">
                  <span className="text-gray-400">Industry:</span>
                  <span className="font-semibold capitalize">{campaignData.industry}</span>
                </div>
                <div className="flex justify-between border-t border-dark-tertiary pt-4">
                  <span className="text-gray-400">Platforms:</span>
                  <span className="font-semibold">{campaignData.platforms.join(', ') || 'None selected'}</span>
                </div>
                <div className="flex justify-between border-t border-dark-tertiary pt-4">
                  <span className="text-gray-400">Budget:</span>
                  <span className="font-semibold">${campaignData.budget}/month</span>
                </div>
              </div>

              <div className="bg-accent/10 border border-accent/50 rounded-lg p-4">
                <p className="text-accent text-sm">
                  ✓ Your campaign is ready to be created. Click "Create Campaign" to proceed.
                </p>
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-4 mt-8">
            {step > 1 && (
              <button
                onClick={() => setStep(step - 1)}
                className="px-6 py-3 bg-dark-tertiary hover:bg-dark-tertiary/80 rounded-lg transition font-semibold"
              >
                ← Back
              </button>
            )}
            {step < 3 ? (
              <button
                onClick={handleNext}
                className="flex-1 px-6 py-3 bg-accent text-dark rounded-lg hover:bg-accent-light transition font-semibold"
              >
                Next →
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="flex-1 px-6 py-3 bg-accent text-dark rounded-lg hover:bg-accent-light transition font-semibold"
              >
                Create Campaign
              </button>
            )}
            <Link href="/dashboard">
              <button className="px-6 py-3 bg-dark-tertiary hover:bg-dark-tertiary/80 rounded-lg transition font-semibold">
                Cancel
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
