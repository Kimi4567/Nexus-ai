'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'

export default function CampaignResultsPage() {
  const { isAuthenticated, loading } = useAuth()
  const params: any = useParams()
  const campaignId = params?.campaignId
  const router = useRouter()
  const [data, setData] = useState<any>(null)

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      router.push('/auth/login')
      return
    }
    ;(async () => {
      try {
        const res = await fetch(`/api/campaigns/${campaignId}`)
        const json = await res.json()
        if (json.campaign) setData(json.campaign)
      } catch (err) {}
    })()
  }, [campaignId, isAuthenticated, loading, router])

  if (loading) return <div className="min-h-screen bg-dark flex items-center justify-center">Loading...</div>
  if (!isAuthenticated) return null
  if (!data) return <div className="min-h-screen bg-dark flex items-center justify-center">No results yet.</div>

  const strategy = data.strategy || {}
  const concepts = data.concepts || []
  const generations = data.generations || []

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary">
      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8">
          <h1 className="text-2xl font-bold mb-4">Generation Results — {data.name}</h1>

          <section className="mb-6">
            <h2 className="text-lg font-semibold">Strategy Summary</h2>
            <div className="mt-2 text-sm text-gray-300">
              <div className="mb-2"><strong>Overview:</strong> {strategy.overview || '—'}</div>
              <div className="mb-2"><strong>Audience:</strong> {strategy.audience || '—'}</div>
              <div className="mb-2"><strong>Key Value Props:</strong> {(strategy.valueProps || []).join(', ') || '—'}</div>
              <div className="mb-2"><strong>Content Pillars:</strong> {(strategy.contentPillars || []).join(', ') || '—'}</div>
              <div className="mb-2"><strong>Platform Recommendations:</strong></div>
              <pre className="text-xs text-gray-400 bg-dark p-3 rounded mt-2">{JSON.stringify(strategy.platformRecommendations || {}, null, 2)}</pre>
            </div>
          </section>

          <section className="mb-6">
            <h2 className="text-lg font-semibold">Ad Concepts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
              {concepts.map((c: any, idx: number) => (
                <div key={idx} className="bg-dark p-4 rounded border border-dark-tertiary">
                  <div className="font-bold">{c.name || `Concept ${idx + 1}`}</div>
                  <div className="text-sm text-gray-400 mt-1">{c.angle}</div>
                  <div className="mt-2 text-sm">{c.description}</div>
                  <div className="mt-2 text-xs text-gray-400">CTA: {c.cta}</div>
                </div>
              ))}
            </div>
          </section>

          <section className="mb-6">
            <h2 className="text-lg font-semibold">Generations</h2>
            <div className="mt-3 space-y-2">
              {generations.length === 0 && <div className="text-sm text-gray-400">No generations yet.</div>}
              {generations.map((g: any) => (
                <div key={g.id} className="bg-dark p-3 rounded border border-dark-tertiary flex justify-between items-center">
                  <div>
                    <div className="font-semibold">{g.type} • {g.status}</div>
                    <div className="text-sm text-gray-400">{g.prompt?.slice(0, 120)}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    {g.output && <a href={g.output} target="_blank" rel="noreferrer" className="text-accent">View</a>}
                    <button onClick={async () => { await fetch('/api/generate', { method: 'POST', body: JSON.stringify({ campaignId: data.id }), headers: { 'Content-Type': 'application/json' } }); alert('Regeneration started') }} className="px-3 py-1 bg-accent text-dark rounded">Regenerate</button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="mb-6">
            <h2 className="text-lg font-semibold">Actions</h2>
            <div className="flex gap-3 mt-3">
              <button onClick={async () => { await fetch('/api/generate', { method: 'POST', body: JSON.stringify({ campaignId: data.id }), headers: { 'Content-Type': 'application/json' } }); alert('Regeneration started') }} className="px-4 py-2 bg-accent text-dark rounded">Regenerate</button>
              <button onClick={async () => { const res = await fetch('/api/exports', { method: 'POST', body: JSON.stringify({ campaignId: data.id }), headers: { 'Content-Type': 'application/json' } }); const json = await res.json(); if (json.export) window.open(json.export.url, '_blank') }} className="px-4 py-2 bg-dark-tertiary rounded">Export</button>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}
