'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import Link from 'next/link'

export default function LoginPage() {
  const router = useRouter()
  const { login } = useAuth()
  const [email, setEmail] = useState('demo@example.com')
  const [password, setPassword] = useState('demo123')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      if (!email || !password) {
        setError('Please enter email and password')
        setLoading(false)
        return
      }
      await login(email, password)
    } catch (err: any) {
      setError(err?.message || 'Login failed. Please try again.')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-dark-secondary border border-dark-tertiary rounded-xl p-8 shadow-xl">
          <Link href="/" className="block mb-8">
            <h1 className="text-3xl font-bold text-accent">NEXUS</h1>
          </Link>

          <h2 className="text-2xl font-bold mb-2">Welcome Back</h2>
          <p className="text-gray-400 mb-8">Sign in to your NEXUS account</p>

          {error && (
            <div className="bg-red-500/20 border border-red-500/50 rounded-lg px-4 py-3 mb-6 text-sm text-red-200">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="demo@example.com"
                className="w-full px-4 py-2 bg-dark border border-dark-tertiary rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-accent transition"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2 bg-dark border border-dark-tertiary rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-accent transition"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2 bg-accent text-dark font-semibold rounded-lg hover:bg-accent-light transition disabled:opacity-50 mt-6"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <p className="text-center text-sm text-gray-400 mt-6">
            Don't have an account?{' '}
            <Link href="/auth/register" className="text-accent hover:text-accent-light transition font-semibold">
              Sign up
            </Link>
          </p>
        </div>

        <p className="text-center text-xs text-gray-500 mt-8">Demo credentials: demo@example.com / demo123</p>
      </div>
    </div>
  )
}
