'use client'

import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'

export default function TemplatesPage() {
  const { isAuthenticated, loading } = useAuth()

  if (loading) return <div className="min-h-screen bg-dark flex items-center justify-center">Loading...</div>
  if (!isAuthenticated) return null

  const mockTemplates = [
    { id: 't1', name: 'Short Product Promo', description: '15s product highlight optimized for TikTok' },
    { id: 't2', name: 'Brand Story', description: '45s storytelling format for YouTube' },
    { id: 't3', name: 'Lead Gen Ad', description: '30s ad with CTA and form capture' },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary">
      <nav className="border-b border-dark-tertiary bg-dark/50 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/dashboard">
            <h1 className="text-2xl font-bold text-accent">NEXUS</h1>
          </Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-8">
          <h1 className="text-3xl font-bold mb-4">Templates</h1>
          <p className="text-gray-400 mb-6">Browse campaign templates to kickstart your next ad.</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {mockTemplates.map(t => (
              <div key={t.id} className="bg-dark rounded-lg border border-dark-tertiary p-4">
                <div className="font-semibold">{t.name}</div>
                <div className="text-sm text-gray-400">{t.description}</div>
                <div className="mt-4 flex gap-2">
                  <button className="px-3 py-2 bg-accent text-dark rounded-lg">Use Template</button>
                  <button className="px-3 py-2 bg-dark-tertiary rounded-lg">Preview</button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8">
            <Link href="/dashboard">
              <button className="px-4 py-2 bg-dark-tertiary rounded-md">Back to Dashboard</button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
