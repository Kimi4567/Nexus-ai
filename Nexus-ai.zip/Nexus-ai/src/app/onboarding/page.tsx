import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth-utils'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'

export default async function OnboardingPage() {
  const session = await getSession()

  if (!session?.user?.id) {
    redirect('/auth/login')
  }

  // Check if user has completed onboarding
  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
  })

  const workspaces = await prisma.workspace.findMany({
    where: { ownerId: session.user.id },
  })

  if (workspaces.length > 0) {
    redirect('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-secondary to-dark-tertiary">
      {/* Steps */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-4">Welcome, {user?.name}!</h1>
          <p className="text-xl text-gray-400">Let's set up your first workspace in 3 steps.</p>
        </div>

        {/* Step 1: Create Workspace */}
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-12 mb-8 animate-fade-in">
          <div className="flex gap-4 mb-6">
            <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center text-accent font-bold text-lg">
              1
            </div>
            <div>
              <h2 className="text-2xl font-bold">Create Your First Workspace</h2>
              <p className="text-gray-400">A workspace is where you organize campaigns and projects.</p>
            </div>
          </div>

          <Link
            href="/workspace/create"
            className="inline-block px-6 py-3 bg-accent text-dark rounded-lg hover:bg-accent-light transition font-semibold"
          >
            Create Workspace
          </Link>
        </div>

        {/* Step 2: Info */}
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-12 mb-8 opacity-50">
          <div className="flex gap-4 mb-6">
            <div className="w-12 h-12 rounded-full bg-gray-600/20 flex items-center justify-center text-gray-400 font-bold text-lg">
              2
            </div>
            <div>
              <h2 className="text-2xl font-bold">Set Up Your Business Profile</h2>
              <p className="text-gray-400">Tell us about your business for better AI recommendations.</p>
            </div>
          </div>
          <button disabled className="inline-block px-6 py-3 bg-gray-600 text-gray-400 rounded-lg cursor-not-allowed font-semibold">
            (Unlocks after step 1)
          </button>
        </div>

        {/* Step 3: Info */}
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-12 opacity-50">
          <div className="flex gap-4 mb-6">
            <div className="w-12 h-12 rounded-full bg-gray-600/20 flex items-center justify-center text-gray-400 font-bold text-lg">
              3
            </div>
            <div>
              <h2 className="text-2xl font-bold">Start Creating Campaigns</h2>
              <p className="text-gray-400">Launch your first AI-powered marketing campaign.</p>
            </div>
          </div>
          <button disabled className="inline-block px-6 py-3 bg-gray-600 text-gray-400 rounded-lg cursor-not-allowed font-semibold">
            (Unlocks after step 2)
          </button>
        </div>

        {/* Benefits */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="text-4xl mb-3">🚀</div>
            <h3 className="font-semibold mb-2">Get Started in Minutes</h3>
            <p className="text-sm text-gray-400">No complex setup or integrations needed.</p>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-3">🎯</div>
            <h3 className="font-semibold mb-2">AI-Powered Strategy</h3>
            <p className="text-sm text-gray-400">Let AI analyze and optimize your campaigns.</p>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-3">📊</div>
            <h3 className="font-semibold mb-2">Track Results</h3>
            <p className="text-sm text-gray-400">See real-time analytics and performance.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
