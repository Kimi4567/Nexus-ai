import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth-utils'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'

export default async function WorkspacePage({
  params,
}: {
  params: { slug: string }
}) {
  const session = await getSession()

  if (!session?.user?.id) {
    redirect('/auth/login')
  }

  const workspace = await prisma.workspace.findUnique({
    where: { slug: params.slug },
    include: {
      projects: {
        include: {
          _count: {
            select: { campaigns: true, media: true },
          },
        },
      },
      members: true,
      _count: {
        select: {
          campaigns: true,
        },
      },
    },
  })

  if (!workspace) {
    redirect('/dashboard')
  }

  // Verify access
  const hasAccess =
    workspace.ownerId === session.user.id ||
    workspace.members?.some((m) => m.userId === session.user?.id)

  if (!hasAccess) {
    redirect('/dashboard')
  }

  return (
    <div className="min-h-screen bg-dark">
      {/* Navigation */}
      <nav className="border-b border-dark-tertiary bg-dark-secondary sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <Link href="/dashboard" className="text-accent hover:text-accent-light transition text-sm">
              ← Workspaces
            </Link>
            <h1 className="text-2xl font-bold mt-2">{workspace.name}</h1>
          </div>
          <div className="flex gap-4">
            <button className="px-4 py-2 border border-dark-tertiary rounded-lg hover:bg-dark-tertiary transition">
              Settings
            </button>
            <Link
              href={`/workspace/${workspace.slug}/project/new`}
              className="px-4 py-2 bg-accent text-dark rounded-lg hover:bg-accent-light transition font-semibold"
            >
              New Project
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-6">
            <div className="text-sm text-gray-400 mb-2">Total Projects</div>
            <div className="text-3xl font-bold">{workspace.projects.length}</div>
          </div>
          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-6">
            <div className="text-sm text-gray-400 mb-2">Active Campaigns</div>
            <div className="text-3xl font-bold">{workspace._count.campaigns}</div>
          </div>
          <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-6">
            <div className="text-sm text-gray-400 mb-2">Team Members</div>
            <div className="text-3xl font-bold">{1 + (workspace.members?.length || 0)}</div>
          </div>
        </div>

        {/* Projects List */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Projects</h2>

          {workspace.projects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {workspace.projects.map(project => (
                <Link
                  key={project.id}
                  href={`/workspace/${workspace.slug}/project/${project.id}`}
                  className="bg-dark-secondary border border-dark-tertiary rounded-lg p-6 hover:border-accent/50 transition group"
                >
                  <h3 className="font-semibold group-hover:text-accent transition mb-2">
                    {project.name}
                  </h3>
                  {project.description && (
                    <p className="text-sm text-gray-400 mb-4">{project.description}</p>
                  )}
                  <div className="flex gap-4 text-sm text-gray-500">
                    <span>{project._count.campaigns} campaigns</span>
                    <span>{project._count.media} assets</span>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-12 text-center">
              <p className="text-gray-400 mb-4">No projects yet</p>
              <Link
                href={`/workspace/${workspace.slug}/project/new`}
                className="text-accent hover:text-accent-light transition"
              >
                Create your first project →
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
