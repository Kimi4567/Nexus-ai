'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function CreateWorkspacePage() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [slug, setSlug] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .trim()
      .replace(/\s+/g, '-')
      .replace(/[^\w\-]/g, '')
  }

  const handleNameChange = (e: string) => {
    setName(e)
    setSlug(generateSlug(e))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const response = await fetch('/api/workspaces', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, slug, description }),
      })

      if (!response.ok) {
        throw new Error('Failed to create workspace')
      }

      const workspace = await response.json()
      router.push(`/workspace/${workspace.slug}`)
    } catch (err) {
      setError('Failed to create workspace')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-dark">
      <nav className="border-b border-dark-tertiary bg-dark-secondary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/dashboard" className="text-accent hover:text-accent-light transition">
            ← Back to Dashboard
          </Link>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-dark-secondary border border-dark-tertiary rounded-lg p-12">
          <h1 className="text-3xl font-bold mb-2">Create Workspace</h1>
          <p className="text-gray-400 mb-8">
            Workspaces help you organize projects and collaborate with your team.
          </p>

          {error && (
            <div className="bg-red-500/20 border border-red-500 rounded-lg px-4 py-3 mb-6 text-sm text-red-200">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold mb-3">Workspace Name</label>
              <input
                type="text"
                value={name}
                onChange={e => handleNameChange(e.target.value)}
                placeholder="My Awesome Brand"
                className="w-full bg-dark-tertiary border border-dark-tertiary rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-accent transition"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3">Workspace URL</label>
              <div className="flex items-center bg-dark-tertiary border border-dark-tertiary rounded-lg px-4">
                <span className="text-gray-400">nexus.ai/</span>
                <input
                  type="text"
                  value={slug}
                  onChange={e => setSlug(e.target.value)}
                  placeholder="my-awesome-brand"
                  className="flex-1 bg-transparent py-3 text-white placeholder-gray-500 focus:outline-none"
                />
              </div>
              <p className="text-xs text-gray-400 mt-2">Lowercase letters, numbers, and hyphens only</p>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3">Description (Optional)</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="What is this workspace for?"
                className="w-full bg-dark-tertiary border border-dark-tertiary rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-accent transition"
                rows={3}
              />
            </div>

            <button
              type="submit"
              disabled={loading || !name || !slug}
              className="w-full bg-accent text-dark font-semibold py-3 rounded-lg hover:bg-accent-light transition disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Create Workspace'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
