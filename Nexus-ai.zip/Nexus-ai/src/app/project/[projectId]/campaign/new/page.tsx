import { CampaignWizard } from '@/components/CampaignWizard'
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth-utils'
import { prisma } from '@/lib/prisma'

export default async function NewCampaignPage({
  params,
}: {
  params: { projectId: string }
}) {
  const session = await getSession()

  if (!session?.user?.id) {
    redirect('/auth/login')
  }

  // Verify project access
  const project = await prisma.project.findFirst({
    where: {
      id: params.projectId,
      workspace: {
        ownerId: session.user.id,
      },
    },
    include: {
      workspace: true,
    },
  })

  if (!project) {
    redirect('/dashboard')
  }

  return <CampaignWizard projectId={params.projectId} workspaceId={project.workspaceId} />
}
