import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.SUPABASE_URL || ''
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY || ''

if (!supabaseUrl || !supabaseServiceKey) {
  console.warn('Supabase service key or URL missing — supabase auth helper will be limited.')
}

const admin = createClient(supabaseUrl, supabaseServiceKey)

export async function verifySupabaseToken(accessToken?: string) {
  if (!accessToken) return null
  try {
    const { data, error } = await admin.auth.getUser(accessToken)
    if (error) {
      console.warn('Supabase token verification failed', error)
      return null
    }
    return data.user
  } catch (err) {
    console.error('verifySupabaseToken error', err)
    return null
  }
}

export default { verifySupabaseToken }
