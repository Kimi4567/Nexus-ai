import { getServerSession } from 'next-auth/next'
import { authOptions } from './auth'

export interface AuthenticatedUser {
  id: string
  name?: string | null
  email?: string | null
  image?: string | null
}

export async function getSession() {
  return getServerSession(authOptions)
}

export async function getCurrentUser(): Promise<AuthenticatedUser | null> {
  const session = await getSession()
  return session?.user as AuthenticatedUser | null
}

export async function requireAuth(): Promise<AuthenticatedUser> {
  const user = await getCurrentUser()
  if (!user) {
    throw new Error('Authentication required')
  }
  return user
}
