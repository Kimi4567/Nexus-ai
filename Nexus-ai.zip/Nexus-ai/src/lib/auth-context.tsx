'use client'

import { ReactNode, useEffect, useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import supabase from './supabaseClient'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    setIsReady(true)
  }, [])

  if (!isReady) return <div className="min-h-screen bg-dark flex items-center justify-center">Loading...</div>

  return <>{children}</>
}

export function useAuth() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const { data } = await supabase.auth.getUser()
        if (mounted) setUser(data.user || null)
      } catch (err) {
        console.warn('Supabase getUser error', err)
      } finally {
        if (mounted) setLoading(false)
      }
    })()

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null)
    })

    return () => {
      mounted = false
      sub.subscription.unsubscribe()
    }
  }, [])

  const login = async (email: string, password: string) => {
    setLoading(true)
    const res = await supabase.auth.signInWithPassword({ email, password })
    if (res.error) throw res.error
    setUser(res.data.user)
    router.push('/dashboard')
    setLoading(false)
  }

  const signup = async (email: string, password: string, options?: { name?: string }) => {
    setLoading(true)
    const res = await supabase.auth.signUp({ email, password, options: { data: { name: options?.name } } })
    if (res.error) throw res.error
    setUser(res.data.user)
    router.push('/dashboard')
    setLoading(false)
  }

  const logout = async () => {
    await supabase.auth.signOut()
    setUser(null)
    router.push('/')
  }

  return { user, loading, login, signup, logout, isAuthenticated: !!user }
}

export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { isAuthenticated, loading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (!loading && !isAuthenticated && !pathname.startsWith('/auth')) {
      router.push('/auth/login')
    }
  }, [loading, isAuthenticated, pathname, router])

  if (loading) {
    return <div className="min-h-screen bg-dark flex items-center justify-center">Loading...</div>
  }

  if (!isAuthenticated) return null

  return <>{children}</>
}
