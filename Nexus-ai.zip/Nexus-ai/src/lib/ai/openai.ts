/**
 * OpenAI/Claude integration
 * In production, use official SDK with streaming
 */

export async function callOpenAI(prompt: string): Promise<any> {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are an expert marketing strategist and creative director.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.8,
        max_tokens: 2000,
      }),
    })

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`)
    }

    const data = await response.json()
    return data.choices[0].message.content
  } catch (error) {
    console.error('OpenAI call failed:', error)
    throw error
  }
}

export async function generateScript(briefing: string): Promise<string> {
  const prompt = `Write a compelling 30-60 second video script for:

${briefing}

Requirements:
- Hook in first 3 seconds
- Problem + solution format
- Clear CTA
- Platform-appropriate language

Return only the script text.`

  return callOpenAI(prompt)
}

export async function generateCaptions(script: string, platform: string): Promise<string[]> {
  const prompt = `Generate 3 caption variations for ${platform} for this video script:

${script}

Each should be optimized for ${platform}'s algorithm and audience.
Return as JSON array of strings.`

  const result = await callOpenAI(prompt)
  return typeof result === 'string' ? JSON.parse(result) : result
}

export async function generateMarketingStrategy(campaign: any, project: any): Promise<any> {
  const prompt = `You are an expert marketing strategist. Based on this campaign and project data, return a JSON object with overview, audience, valueProps, angles, platformRecommendations, metrics, contentPillars, positioning, ctaStrategies, and risks.

PROJECT: ${JSON.stringify(project, null, 2)}
CAMPAIGN: ${JSON.stringify(campaign, null, 2)}`
  const result = await callOpenAI(prompt)
  return typeof result === 'string' ? JSON.parse(result) : result
}

export async function generateAdConcepts(campaign: any, project: any): Promise<any> {
  const prompt = `You are a creative director. Generate 5 ad concepts in JSON array format with name, description, angle, script, cta, headlines, and captions based on this campaign and project data.

PROJECT: ${JSON.stringify(project, null, 2)}
CAMPAIGN: ${JSON.stringify(campaign, null, 2)}`
  const result = await callOpenAI(prompt)
  return typeof result === 'string' ? JSON.parse(result) : result
}
