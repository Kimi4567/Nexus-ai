/**
 * Mock AI adapter used when OPENAI_API_KEY is not provided.
 * Returns deterministic placeholder content suitable for UI and testing.
 */
export async function callOpenAI(prompt: string): Promise<any> {
  console.log('Mock OpenAI called with prompt:', prompt.slice(0, 200))
  return JSON.stringify({ mock: true, promptSummary: prompt.slice(0, 200) })
}

export async function generateScript(briefing: string): Promise<string> {
  return `Mock 30s video script for: ${briefing.slice(0, 120)}...\nHook: Start with a bold statement.\nBody: Present problem and solution.\nCTA: Visit yoursite.com to learn more.`
}

export async function generateCaptions(script: string, platform: string): Promise<string[]> {
  return [
    `Mock caption 1 for ${platform}: Short and punchy.`,
    `Mock caption 2 for ${platform}: Includes CTA.`,
    `Mock caption 3 for ${platform}: Emoji-friendly.`,
  ]
}

export async function generateMarketingStrategy(campaign: any, project: any) {
  return {
    overview: `Mock strategy for ${campaign.name || 'Campaign'}`,
    audience: 'Mock audience: small business owners, 25-45',
    valueProps: ['Clear benefit A', 'Clear benefit B'],
    angles: ['Angle 1', 'Angle 2'],
    platformRecommendations: { instagram: 'Short reels', tiktok: 'Native hooks' },
    metrics: { ctr: 0.02, conv: 0.01 },
    contentPillars: ['Pillar 1', 'Pillar 2'],
    positioning: 'Mock positioning',
    ctaStrategies: ['CTA 1', 'CTA 2'],
    risks: ['Risk 1', 'Risk 2'],
  }
}

export async function generateAdConcepts(campaign: any, project: any) {
  const concepts = []
  for (let i = 1; i <= 5; i++) {
    concepts.push({
      name: `Mock Concept ${i}`,
      description: `A mock ad concept focusing on benefit ${i}`,
      angle: `Angle ${i}`,
      script: `Mock script ${i}`,
      cta: `Learn more at yoursite.com`,
      headlines: [`Headline A${i}`, `Headline B${i}`],
      captions: [`Caption A${i}`, `Caption B${i}`],
    })
  }
  return concepts
}
