import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { verifySupabaseToken } from '@/lib/supabaseAuth'

export async function getServerUserId(req: Request) {
  const session = (await getServerSession(authOptions as any)) as any
  if (session && session.user?.id) return session.user.id

  const authHeader = req.headers.get('authorization') || ''
  const token = authHeader.replace('Bearer ', '')
  const sbUser = await verifySupabaseToken(token || undefined)
  if (sbUser && (sbUser as any).id) return (sbUser as any).id

  return null
}
